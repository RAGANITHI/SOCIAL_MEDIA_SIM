package com.insignia.socialmediasim.ui.upload;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.insignia.socialmediasim.R;
import com.squareup.picasso.Picasso;

import static android.app.Activity.RESULT_OK;

public class UploadFragment extends Fragment {

    private DashboardViewModel dashboardViewModel;
    EditText desc;
    String Desc,nop,Name,UID,url;
    Button upload;
    ImageView imageView;
    Uri imageContainer;
    StorageReference storageReference;
    DatabaseReference databaseReference;
    public View onCreateView(@NonNull final LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel =
                ViewModelProviders.of(this).get(DashboardViewModel.class);
        View root = inflater.inflate(R.layout.fragment_upload, container, false);
        //final TextView textView = root.findViewById(R.id.text_dashboard);
        desc=root.findViewById(R.id.Editdesc);
        upload=root.findViewById(R.id.upbutton);
        imageView=root.findViewById(R.id.tapup);
        databaseReference=FirebaseDatabase.getInstance().getReference();
        storageReference=FirebaseStorage.getInstance().getReference();
        UID=FirebaseAuth.getInstance().getUid();
        dashboardViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                //textView.setText(s);
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        nop=dataSnapshot.child("nop").getValue().toString();
                        Name=dataSnapshot.child(UID).child("Name").getValue().toString();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent=new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(Intent.createChooser(intent,"Select an image"),1);
                    }
                });
                upload.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Desc=desc.getText().toString();
                        if((Desc!=null)&&(imageContainer!=null)&&(nop!=null)&&(Name!=null)){
                            upload.setEnabled(false);
                            Toast.makeText(getActivity(),"Uploading content please wait",Toast.LENGTH_SHORT).show();
                            storageReference.child(nop).putFile(imageContainer).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(getActivity(),"Upload Falied",Toast.LENGTH_SHORT).show();
                                    upload.setEnabled(true);
                                }
                            }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    Task<Uri> downurl = taskSnapshot.getStorage().getDownloadUrl();
                                    while (!(downurl.isComplete()));
                                    url=downurl.getResult().toString();
                                    databaseReference.child("Feeds").child(nop).child("name").setValue(Name);
                                    databaseReference.child("Feeds").child(nop).child("url").setValue(url);
                                    databaseReference.child("Feeds").child(nop).child("desc").setValue(Desc);
                                    databaseReference.child("nop").setValue(Integer.parseInt(nop)+1);
                                    Toast.makeText(getActivity(),"Uploaded",Toast.LENGTH_SHORT).show();

                                }
                            });
                        }
                        else{
                            Toast.makeText(getActivity(),"Data field missing",Toast.LENGTH_SHORT).show();
                        }

                    }
                });


            }
        });
        return root;
    }
    public void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if((requestCode==1)&&(resultCode==RESULT_OK)&&(data!=null)&&(data.getData()!=null)){
            try{
                imageContainer=data.getData();
                Picasso.get().load(imageContainer).fit().into(imageView);
            }
            catch (Exception e){

            }
        }
    }


}