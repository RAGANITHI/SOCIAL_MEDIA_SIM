package com.insignia.socialmediasim;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity2 extends AppCompatActivity {
    EditText email,pass;
    String Email,Pass;
    Button login;
    TextView tv;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        email=findViewById(R.id.editTextTextEmailAddress);
        pass=findViewById(R.id.editTextTextPassword);
        login=findViewById(R.id.button);
        tv=findViewById(R.id.textView);
        firebaseAuth=FirebaseAuth.getInstance();
        if(FirebaseAuth.getInstance().getCurrentUser()==null) {
            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Email = email.getText().toString();
                    Pass = pass.getText().toString();
                    if ((Email.equals("")) || (Pass.equals(""))) {
                        Toast.makeText(MainActivity2.this, "Enter all the fields", Toast.LENGTH_SHORT).show();
                    } else if ((!(Email.equals(""))) && (!(Pass.equals("")))) {
                        firebaseAuth.signInWithEmailAndPassword(Email, Pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(MainActivity2.this, "Auth Failed", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }

                }
            });
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity2.this, SignupActivity.class);
                    startActivity(intent);

                }
            });
        }
        else{
            Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
            startActivity(intent);
        }
    }

}