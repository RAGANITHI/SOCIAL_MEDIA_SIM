package com.insignia.socialmediasim.ui.feeds;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.insignia.socialmediasim.R;
import com.squareup.picasso.Picasso;



public class FeedsFragment extends Fragment {

    private NotificationsViewModel notificationsViewModel;
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        notificationsViewModel =
                ViewModelProviders.of(this).get(NotificationsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_feeds, container, false);
        // TextView textView = root.findViewById(R.id.text_notifications);
        databaseReference=FirebaseDatabase.getInstance().getReference("Feeds");
        recyclerView=root.findViewById(R.id.recy);
        databaseReference.keepSynced(true);
        recyclerView.hasFixedSize();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        notificationsViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                //.setText(s);
                FirebaseRecyclerAdapter<data,dataViewHolder> firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<data, dataViewHolder>
                        (data.class,R.layout.card,dataViewHolder.class,databaseReference) {
                    @Override
                    protected void populateViewHolder(dataViewHolder dataViewHolder, data data, int i) {
                        dataViewHolder.setName(data.getName());
                        dataViewHolder.setDesc(data.getDesc());
                        dataViewHolder.setUrl(data.getUrl());

                    }
                };
                recyclerView.setAdapter(firebaseRecyclerAdapter);
            }
        });
        return root;
    }
    public static class dataViewHolder extends RecyclerView.ViewHolder {
        View view;

        public dataViewHolder(@NonNull View item) {
            super(item);
            view = item;
        }
        public void setName(String name){
            TextView post=view.findViewById(R.id.recusername);
            post.setText(name);
        }
        public void setDesc(String desc){
            TextView post=view.findViewById(R.id.recdesc);
            post.setText(desc);
        }
        public void setUrl(String url){
            ImageView imageView=view.findViewById(R.id.recimage);
            Picasso.get().load(url).fit().into(imageView);
        }
    }

}