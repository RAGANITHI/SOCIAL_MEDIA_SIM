package com.insignia.socialmediasim;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignupActivity extends AppCompatActivity {
    EditText email,pass;
    String Email,Pass;
    Button signup;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        email=findViewById(R.id.editTextTextEmailAddress1);
        pass=findViewById(R.id.editTextTextPassword1);
        signup=findViewById(R.id.button1);
        firebaseAuth=FirebaseAuth.getInstance();
    signup.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Email=email.getText().toString();
            Pass=pass.getText().toString();
            if((Email.equals(""))||(Pass.equals(""))){
                Toast.makeText(SignupActivity.this,"Enter all the fields",Toast.LENGTH_SHORT).show();
            }
            else if((!(Email.equals("")))&&(!(Pass.equals("")))){
                firebaseAuth.createUserWithEmailAndPassword(Email,Pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        Intent intent=new Intent(SignupActivity.this,MainActivity3.class);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(SignupActivity.this,"User Creation Failed",Toast.LENGTH_SHORT).show();

                    }
                    }
                });
            }

        }
    });
    }

}